import React, { useState } from 'react';
import './App.css';
import logo from './logo.jpg';

function App() {
  const [text, setText] = useState('');
  const [result, setResult] = useState('');

  const encrypt = async () => {
    const res = await fetch('http://localhost:8080/api/encrypt', {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain' },
      body: text
    });
    const data = await res.text();
    setResult(data);
  };

  const decrypt = async () => {
    const res = await fetch('http://localhost:8080/api/decrypt', {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain' },
      body: text
    });
    const data = await res.text();
    setResult(data);
  };

  return (
    <div className="App">
      <img src={logo} alt="Honeywell" style={{ width: 100 }} />
      <h2>Encrypt / Decrypt Tool</h2>
      <textarea rows="4" cols="50" value={text} onChange={(e) => setText(e.target.value)} />
      <br />
      <button onClick={encrypt}>Encrypt</button>
      <button onClick={decrypt}>Decrypt</button>
      <h3>Result:</h3>
      <div>{result}</div>
    </div>
  );
}

export default App;
